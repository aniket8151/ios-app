# Working with MusicKit and SwiftUI

In this tutorial, we will walk you through the MusicKit framework by building a Music Player using SwiftUI. For the full tutorial, please check it out here:

https://www.appcoda.com/musickit-music-player-swiftui/
